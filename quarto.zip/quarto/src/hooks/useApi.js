// Importação do useState para criar as variaveis
import { useState, useEffect } from "react";

// Varialvel para url da API, vindo arquivo .env
const url = import.meta.env.VITE_API_URL

//Função para requisitar todos os funcionários
export function getFuncionarios() {
    const [funcionarios, setFuncionarios] = useState([]);

    useEffect( () => {
        async function  fetchData() {
            try {
                const response = await fetch(url)
                const data = await response.json()
                setFuncionarios(data)
                console.log("Dados recebidos:", data);
            } catch (error) {
                console.log("Erro ao buscar os dados:", error);
            }
        }
        fetchData()
    }, [])
    return funcionarios;
}

export function addFuncionario(funcionario) {
    async function  fetchData2() {
        try {
            const response = await fetch(url, {
                method: "POST",
                headers: {"Content-type": "application/json"},
                body: JSON.stringify(funcionario)
            })
            const data = await response.json()
            console.log("Usuário adicionado", data)
        } catch (error) {
            console.log("Erro ao cadastrar funcionário:", error);
        }
    }
    fetchData2()
}